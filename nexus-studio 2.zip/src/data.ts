/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  NavLink,
  StatItem,
  ServiceItem,
  PortfolioItem,
  ProcessStep,
  Testimonial,
  PricingPlan,
} from './types';

export const navLinks: NavLink[] = [
  { label: 'Services', href: '#services' },
  { label: 'Work', href: '#work' },
  { label: 'Process', href: '#process' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Contact', href: '#contact' },
];

export const trustedLogos: string[] = [
  'Streamline',
  'Vertex Labs',
  'Orbit Digital',
  'Quantum',
  'Praxis Co.',
  'Altova',
  'Meridian',
  'CoreSync',
  'Vaultline',
  'NovaBridge',
];

export const heroStats: StatItem[] = [
  { number: '200+', label: 'Projects Delivered' },
  { number: '98%', label: 'Client Satisfaction' },
  { number: '8yr', label: 'Industry Expertise' },
];

export const values: string[] = [
  'Results-First Approach',
  'Transparent Workflow',
  'Pixel-Perfect Craft',
  'Scalable Architecture',
];

export const services: ServiceItem[] = [
  {
    icon: '🌐',
    title: 'Web Development',
    description: 'Performance-first websites and web applications built with modern stacks. From landing pages to complex SaaS platforms.',
  },
  {
    icon: '📱',
    title: 'App Development',
    description: 'Cross-platform mobile apps engineered for scale. Native performance with React Native and Flutter.',
  },
  {
    icon: '🎨',
    title: 'UI/UX Design',
    description: 'Research-driven interfaces that feel intuitive and look stunning. We design for conversion, not just aesthetics.',
  },
  {
    icon: '📈',
    title: 'SEO & Growth',
    description: 'Data-backed strategies that compound over time. Technical SEO, content architecture, and organic acquisition systems.',
  },
  {
    icon: '💎',
    title: 'Brand Identity',
    description: 'From naming to visual systems, we craft brand identities that resonate and remain consistent across every touchpoint.',
  },
  {
    icon: '🚀',
    title: 'Digital Marketing',
    description: 'Paid media, email automation, and retention strategies that turn your marketing budget into measurable ROI.',
  },
];

export const portfolioItems: PortfolioItem[] = [
  {
    id: 'vaultline',
    category: 'web',
    categoryLabel: 'E-Commerce · Web Development',
    title: 'Vaultline Commerce Platform',
    description: 'Complete rebuild of a Shopify-based store with custom checkout flow and performance overhaul.',
    emoji: '🛒',
    gradient: 'from-[#1a0a2e] to-[#0a0a1e]',
    metrics: [
      { label: 'Revenue Growth', value: '+147%' },
      { label: 'Load Time', value: '3.2s → 0.8s' },
      { label: 'Conversion Rate', value: '+63%' },
    ],
  },
  {
    id: 'meridian',
    category: 'brand',
    categoryLabel: 'Branding · Identity',
    title: 'Meridian Brand Refresh',
    description: 'Full brand identity overhaul for a B2B SaaS targeting enterprise financial services.',
    emoji: '💎',
    gradient: 'from-[#0a1e1a] to-[#0a1428]',
    metrics: [
      { label: 'Brand Recall', value: '+89%' },
      { label: 'Demo Requests', value: '+220%' },
    ],
  },
  {
    id: 'orbit',
    category: 'app',
    categoryLabel: 'Mobile · App Development',
    title: 'Orbit Fitness App',
    description: 'Cross-platform fitness tracking app with AI-powered training plans and wearable sync.',
    emoji: '📱',
    gradient: 'from-[#1a0a14] to-[#0a0a1e]',
    metrics: [
      { label: 'Downloads', value: '82K' },
      { label: 'App Store Rating', value: '4.8★' },
    ],
  },
  {
    id: 'quantum',
    category: 'seo',
    categoryLabel: 'SEO · Content Strategy',
    title: 'Quantum Health SEO',
    description: '12-month SEO overhaul targeting high-intent healthcare keywords in 6 markets.',
    emoji: '📈',
    gradient: 'from-[#0a1e0a] to-[#0a0a1e]',
    metrics: [
      { label: 'Organic Traffic', value: '+312%' },
      { label: 'Target Keywords', value: 'Pos 1' },
    ],
  },
  {
    id: 'praxis',
    category: 'web',
    categoryLabel: 'Web · SaaS Platform',
    title: 'Praxis Analytics Dashboard',
    description: 'End-to-end product design and development for a B2B analytics SaaS platform.',
    emoji: '🏢',
    gradient: 'from-[#1e1a0a] to-[#0a0a1e]',
    metrics: [
      { label: 'Churn Rate', value: '40%↓' },
      { label: 'Activation', value: '+58%' },
    ],
  },
];

export const globalStats: StatItem[] = [
  { number: '200+', label: 'Projects Delivered' },
  { number: '98%', label: 'Client Satisfaction' },
  { number: '$40M+', label: 'Revenue Generated for Clients' },
  { number: '8yr', label: 'Average Team Experience' },
];

export const processSteps: ProcessStep[] = [
  {
    icon: '🔍',
    title: 'Discovery',
    description: 'Deep dive into your business, competitors, and users. We define success before a single pixel is drawn.',
  },
  {
    icon: '🎯',
    title: 'Strategy',
    description: 'Architecture, positioning, and a clear roadmap. We align design and engineering goals before building.',
  },
  {
    icon: '⚡',
    title: 'Execution',
    description: 'Design sprints and agile development. You get weekly updates and full visibility throughout.',
  },
  {
    icon: '📊',
    title: 'Growth',
    description: 'Launch, measure, and optimize. We don\'t consider a project done until the metrics are moving.',
  },
];

export const testimonials: Testimonial[] = [
  {
    rating: 5,
    quote: 'Nexus transformed our e-commerce experience from the ground up. Revenue grew 147% in the first six months and our team can actually update the site without developer help now.',
    author: 'Sarah Reynolds',
    role: 'CEO, Vaultline Commerce',
    avatarInitials: 'SR',
  },
  {
    rating: 5,
    quote: 'The new brand identity completely changed how enterprise buyers perceive us. Demo requests jumped 220% within 60 days of launch. Worth every penny.',
    author: 'David Kim',
    role: 'Founder, Meridian Labs',
    avatarInitials: 'DK',
  },
  {
    rating: 5,
    quote: 'Most agencies over-promise and under-deliver. Nexus gave us weekly updates, hit every deadline, and the SEO results speak for themselves — 312% organic growth.',
    author: 'Maria Jensen',
    role: 'Head of Growth, Quantum Health',
    avatarInitials: 'MJ',
  },
  {
    rating: 5,
    quote: 'The Orbit app has a 4.8 star rating and 82,000 downloads in its first year. Nexus built something our users genuinely love, and the architecture scales effortlessly.',
    author: 'Alex Okonkwo',
    role: 'CTO, Orbit Fitness',
    avatarInitials: 'AO',
  },
  {
    rating: 5,
    quote: 'Nexus redesigned our entire dashboard UX. Churn dropped 40%, activation improved 58%. They care about outcomes, not just deliverables.',
    author: 'Lisa Park',
    role: 'Product Lead, Praxis',
    avatarInitials: 'LP',
  },
];

export const pricingPlans: PricingPlan[] = [
  {
    badge: 'Starter',
    badgeType: 'standard',
    name: 'Launch',
    description: 'Perfect for startups and small businesses ready to establish a strong digital presence.',
    price: '2,500',
    period: '/ project',
    note: 'One-time. Delivered in 3 weeks.',
    features: [
      { text: '5-page website design + dev', included: true },
      { text: 'Mobile-first responsive', included: true },
      { text: 'Basic SEO setup', included: true },
      { text: '2 rounds of revisions', included: true },
      { text: 'CMS integration', included: true },
      { text: 'Custom animations', included: false },
      { text: 'Analytics dashboard', included: false },
    ],
    buttonText: 'Get Started',
  },
  {
    badge: 'Most Popular',
    badgeType: 'popular',
    name: 'Growth',
    description: 'For growing brands that need a complete digital strategy and a site that converts.',
    price: '6,500',
    period: '/ project',
    note: 'One-time. Delivered in 6 weeks.',
    isFeatured: true,
    urgency: 'Only 3 slots left this month',
    features: [
      { text: 'Up to 15-page custom build', included: true },
      { text: 'Advanced animations & UX', included: true },
      { text: 'Full SEO strategy', included: true },
      { text: 'Unlimited revisions', included: true },
      { text: 'Analytics + conversion tracking', included: true },
      { text: '3 months post-launch support', included: true },
      { text: 'Performance optimization', included: true },
    ],
    buttonText: 'Start Growing →',
  },
  {
    badge: 'Enterprise',
    badgeType: 'enterprise',
    name: 'Scale',
    description: 'Full-service digital partnership for established companies with complex needs.',
    price: 'Custom',
    note: 'Monthly retainer. Flexible scope.',
    features: [
      { text: 'Dedicated cross-functional team', included: true },
      { text: 'Product + marketing strategy', included: true },
      { text: 'Ongoing development sprints', included: true },
      { text: 'A/B testing & CRO', included: true },
      { text: 'Priority 24/7 support', included: true },
      { text: 'Monthly strategy calls', included: true },
      { text: 'White-glove onboarding', included: true },
    ],
    buttonText: 'Talk to Us →',
  },
];
