/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Calculator, Check, DollarSign, Globe, Sparkles, Zap, ArrowRight, RefreshCw } from 'lucide-react';
import { useTheme } from './ThemeContext';

interface ServiceOption {
  id: string;
  name: string;
  icon: string;
  basePriceUSD: number;
  description: string;
}

interface ScaleOption {
  id: string;
  name: string;
  scaleFactor: number;
  description: string;
}

interface FeatureOption {
  id: string;
  name: string;
  priceUSD: number;
  description: string;
}

interface TimelineOption {
  id: string;
  name: string;
  premiumFactor: number;
  durationText: string;
}

const SERVICES_TYPE: ServiceOption[] = [
  { id: 'website', name: 'Web/Landing Page', icon: '🌐', basePriceUSD: 2500, description: 'Optimized high-converting corporate sites' },
  { id: 'saas', name: 'SaaS / Portal Platform', icon: '🏢', basePriceUSD: 8500, description: 'Client portal, database, or analytics panels' },
  { id: 'mobile', name: 'Mobile App', icon: '📱', basePriceUSD: 12000, description: 'Native or cross-platform iOS & Android solutions' },
  { id: 'ecommerce', name: 'E-Commerce Store', icon: '🛒', basePriceUSD: 4500, description: 'Custom styled checkout & inventory systems' },
];

const SCALES_TYPE: ScaleOption[] = [
  { id: 'starter', name: 'Launch Scale', scaleFactor: 1.0, description: 'Standard pages, standard architecture' },
  { id: 'growth', name: 'Growth Scale', scaleFactor: 1.4, description: 'Advanced SEO, animations, analytics, custom flows' },
  { id: 'enterprise', name: 'Enterprise Elite', scaleFactor: 2.0, description: 'High-availability, scale, SLAs, multi-role auth' },
];

const ADDONS_FEATURES: FeatureOption[] = [
  { id: 'seo', name: 'Technical SEO Audit & Strategy', priceUSD: 800, description: 'Initial baseline research and architecture scaling' },
  { id: 'crm', name: 'CMS & CRM Admin Syncing', priceUSD: 1200, description: 'Synchronize HubSpot/Salesforce or custom control dashboards' },
  { id: 'animations', name: 'Premium Custom Animations & UX', priceUSD: 600, description: 'Complex interactions using Framer-motion or Canvas vectors' },
  { id: 'languages', name: 'Multi-language Localization', priceUSD: 1000, description: 'Fully auto-routing translation parameters (i18n)' },
  { id: 'ai', name: 'AI / LLM Integration (Gemini)', priceUSD: 2500, description: 'Add intelligent automation, auto-tagging, or AI assistance' },
];

const TIMELINE_SPEED: TimelineOption[] = [
  { id: 'standard', name: 'Standard Sprints', premiumFactor: 1.0, durationText: 'Standard timeline' },
  { id: 'rush', name: 'Rush Program (30% Faster)', premiumFactor: 1.25, durationText: 'Express deployment speed' },
];

const CURRENCIES = [
  { code: 'USD', symbol: '$', rate: 1.0, label: 'US Dollar (Intl)' },
  { code: 'EUR', symbol: '€', rate: 0.92, label: 'Euro (Intl)' },
  { code: 'GBP', symbol: '£', rate: 0.79, label: 'British Pound (Intl)' },
  { code: 'INR', symbol: '₹', rate: 83.5, label: 'Indian Rupee (Local)' },
];

export default function CostCalculator() {
  const { theme } = useTheme();
  
  // Choice state
  const [selectedService, setSelectedService] = useState<string>('saas');
  const [selectedScale, setSelectedScale] = useState<string>('growth');
  const [selectedAddons, setSelectedAddons] = useState<string[]>(['seo', 'animations']);
  const [selectedTimeline, setSelectedTimeline] = useState<string>('standard');
  const [selectedCurrency, setSelectedCurrency] = useState<string>('USD');

  // Multi-currency rates calculation Helper
  const currencyInfo = CURRENCIES.find((c) => c.code === selectedCurrency) || CURRENCIES[0];

  // Price Calculation Logic
  const serviceBase = SERVICES_TYPE.find((s) => s.id === selectedService)?.basePriceUSD || 0;
  const scaleMultiplier = SCALES_TYPE.find((s) => s.id === selectedScale)?.scaleFactor || 1.0;
  const addonsSum = ADDONS_FEATURES.filter((f) => selectedAddons.includes(f.id)).reduce((sum, f) => sum + f.priceUSD, 0);
  const timelineMultiplier = TIMELINE_SPEED.find((t) => t.id === selectedTimeline)?.premiumFactor || 1.0;

  const finalCostPriceUSD = Math.round((serviceBase * scaleMultiplier + addonsSum) * timelineMultiplier);

  // Toggle addon helper
  const handleAddonToggle = (id: string) => {
    setSelectedAddons((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const formattedCost = (usdVal: number) => {
    const rawCalc = usdVal * currencyInfo.rate;
    return new Intl.NumberFormat(undefined, {
      style: 'currency',
      currency: currencyInfo.code,
      maximumFractionDigits: 0,
    }).format(rawCalc);
  };

  return (
    <section 
      className={`py-24 sm:py-32 border-y transition-all duration-[400ms] ease-in-out ${
        theme === 'light' 
          ? 'bg-[#F8FAFC] border-slate-100 text-slate-800' 
          : 'bg-[#111827] border-white/5 text-[#F0EDFF]'
      }`} 
      id="cost-calculator"
    >
      <div className="max-w-[1200px] mx-auto px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-[720px] mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold tracking-wider uppercase text-[#A855F7] bg-[#7C3AED]/8 border border-[#7C3AED]/20 mb-5">
            Cost Matrix
          </div>
          <h2 className={`font-display text-3xl sm:text-4xl lg:text-[48px] font-bold leading-[1.1] mb-5 transition-colors duration-[400ms] ${
            theme === 'light' ? 'text-[#0F172A]' : 'text-white'
          }`}>
            Interactive <span className="bg-gradient-to-r from-[#2563EB] via-[#7C3AED] to-[#06B6D4] bg-clip-text text-transparent">Project Calculator</span>
          </h2>
          <p className={`text-base sm:text-lg leading-relaxed transition-colors duration-[400ms] ${theme === 'light' ? 'text-[#64748B]' : 'text-[#A09BB8]'}`}>
            Determine localized and international project pricing variables instantly. Lock in estimates for real consultation.
          </p>
        </div>

        {/* Currency Switcher Pill - Top right aligned visually */}
        <div className="flex justify-center md:justify-end items-center gap-3 mb-10 w-full animate-fade-in">
          <span className={`text-xs font-bold uppercase tracking-widest transition-colors duration-[400ms] ${theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'}`}>
            Currency Switcher:
          </span>
          <div className={`flex rounded-lg p-1 border transition-colors duration-[400ms] ${theme === 'light' ? 'bg-slate-200/50 border-slate-300' : 'bg-[#0A0A14] border-white/5'}`}>
            {CURRENCIES.map((cur) => (
              <button
                key={cur.code}
                onClick={() => setSelectedCurrency(cur.code)}
                className={`px-3 py-1.5 rounded-md text-xs font-bold uppercase transition duration-200 cursor-pointer ${
                  selectedCurrency === cur.code
                    ? 'bg-gradient-to-r from-[#2563EB] to-[#7C3AED] text-white shadow-md'
                    : theme === 'light'
                    ? 'text-slate-600 hover:text-black'
                    : 'text-[#6B6590] hover:text-white'
                }`}
              >
                {cur.code} ({cur.symbol})
              </button>
            ))}
          </div>
        </div>

        {/* Main interactive splits */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left panel - Inputs selectors */}
          <div className="lg:col-span-7 flex flex-col gap-6 text-left">
            
            {/* Step 1: Platforms Service */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <span className="w-5 h-5 rounded-full bg-[#7C3AED]/10 text-[#A855F7] text-xs font-bold flex items-center justify-center">1</span>
                <h3 className={`font-display font-bold text-lg transition-colors duration-[400ms] ${theme === 'light' ? 'text-[#0F172A]' : 'text-white'}`}>Select Architecture Focus</h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {SERVICES_TYPE.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setSelectedService(opt.id)}
                    className={`p-4 rounded-xl text-left border transition-all duration-200 cursor-pointer relative overflow-hidden flex flex-col justify-between h-28 ${
                      selectedService === opt.id
                        ? theme === 'light'
                          ? 'border-blue-500 bg-blue-50/50 shadow-md shadow-blue-500/5'
                          : 'border-[#7C3AED] bg-[#7C3AED]/8 shadow-lg shadow-purple-500/5'
                        : theme === 'light'
                        ? 'border-slate-200 bg-white hover:border-slate-400'
                        : 'border-white/5 bg-[#111128]/40 hover:border-purple-500/20'
                    }`}
                  >
                    <div className="flex items-start justify-between w-full">
                      <span className="text-2xl">{opt.icon}</span>
                      {selectedService === opt.id && (
                        <span className={`w-4 h-4 rounded-full flex items-center justify-center ${theme === 'light' ? 'bg-blue-600' : 'bg-[#7C3AED]'}`}>
                          <Check size={10} className="text-white" strokeWidth={3} />
                        </span>
                      )}
                    </div>
                    <div>
                      <div className={`font-bold text-sm ${theme === 'light' ? 'text-[#0F172A]' : 'text-white'}`}>{opt.name}</div>
                      <div className={`text-[11px] truncate leading-tight mt-1 ${theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'}`}>
                        {opt.description}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 2: Scales Factor */}
            <div className="mt-2">
              <div className="flex items-center gap-2 mb-4">
                <span className="w-5 h-5 rounded-full bg-[#7C3AED]/10 text-[#A855F7] text-xs font-bold flex items-center justify-center">2</span>
                <h3 className={`font-display font-bold text-lg transition-colors duration-[400ms] ${theme === 'light' ? 'text-[#0F172A]' : 'text-white'}`}>Define Project Scale & Depth</h3>
              </div>
              <div className="flex flex-col gap-2.5">
                {SCALES_TYPE.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setSelectedScale(opt.id)}
                    className={`p-4 rounded-xl border flex items-center justify-between text-left transition duration-200 cursor-pointer ${
                      selectedScale === opt.id
                        ? theme === 'light'
                          ? 'border-blue-500 bg-blue-50/50'
                          : 'border-[#7C3AED] bg-[#7C3AED]/8'
                        : theme === 'light'
                        ? 'border-slate-200 bg-white hover:border-slate-400'
                        : 'border-white/5 bg-[#111128]/40 hover:border-[#7C3AED]/20'
                    }`}
                  >
                    <div>
                      <div className={`font-bold text-sm flex items-center gap-2 ${theme === 'light' ? 'text-[#0F172A]' : 'text-white'}`}>
                        {opt.name} 
                        {opt.scaleFactor > 1.0 && (
                          <span className={`text-[10px] rounded px-1.5 py-0.5 font-bold ${
                            theme === 'light' ? 'bg-blue-100 text-blue-700' : 'bg-[#7C3AED]/15 text-[#A855F7]'
                          }`}>
                            x{opt.scaleFactor} Multiplier
                          </span>
                        )}
                      </div>
                      <p className={`text-xs mt-1 ${theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'}`}>{opt.description}</p>
                    </div>
                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 ${
                      selectedScale === opt.id 
                        ? theme === 'light' ? 'border-blue-600 bg-blue-100' : 'border-[#7C3AED] bg-[#7C3AED]/30' 
                        : 'border-white/10'
                    }`}>
                      {selectedScale === opt.id && <span className={`w-2.5 h-2.5 rounded-full ${theme === 'light' ? 'bg-blue-600' : 'bg-[#7C3AED]'}`} />}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 3: Addons Features checkboxes */}
            <div className="mt-2">
              <div className="flex items-center gap-2 mb-4">
                <span className="w-5 h-5 rounded-full bg-[#7C3AED]/10 text-[#A855F7] text-xs font-bold flex items-center justify-center">3</span>
                <h3 className={`font-display font-bold text-lg transition-colors duration-[400ms] ${theme === 'light' ? 'text-[#0F172A]' : 'text-white'}`}>Premium Modules & Systems</h3>
              </div>
              <div className="grid grid-cols-1 gap-2">
                {ADDONS_FEATURES.map((opt) => {
                  const isChecked = selectedAddons.includes(opt.id);
                  return (
                    <button
                      key={opt.id}
                      onClick={() => handleAddonToggle(opt.id)}
                      className={`p-3.5 rounded-xl border flex items-center justify-between text-left transition duration-200 cursor-pointer ${
                        isChecked
                          ? theme === 'light'
                            ? 'border-blue-500 bg-blue-50/50'
                            : 'border-[#7C3AED]/60 bg-[#7C3AED]/5'
                          : theme === 'light'
                          ? 'border-slate-200 bg-white hover:border-slate-400'
                          : 'border-white/5 bg-[#111128]/40 hover:border-[#7C3AED]/20'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition ${
                          isChecked 
                            ? theme === 'light' ? 'bg-blue-600 border-transparent' : 'bg-[#7C3AED] border-transparent' 
                            : 'border-white/10'
                        }`}>
                          {isChecked && <Check size={12} className="text-white" strokeWidth={3} />}
                        </div>
                        <div>
                          <div className={`font-bold text-sm ${theme === 'light' ? 'text-[#0F172A]' : 'text-white'}`}>{opt.name}</div>
                          <div className={`text-xs font-medium mt-0.5 ${theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'}`}>
                            {opt.description}
                          </div>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className={`text-sm font-bold ${theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'}`}>
                          +{formattedCost(opt.priceUSD)}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 4: Speed parameters */}
            <div className="mt-2">
              <div className="flex items-center gap-2 mb-4">
                <span className="w-5 h-5 rounded-full bg-[#7C3AED]/10 text-[#A855F7] text-xs font-bold flex items-center justify-center">4</span>
                <h3 className={`font-display font-bold text-lg transition-colors duration-[400ms] ${theme === 'light' ? 'text-[#0F172A]' : 'text-white'}`}>Deployment Pace</h3>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {TIMELINE_SPEED.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setSelectedTimeline(opt.id)}
                    className={`p-4 rounded-xl text-center border transition-all duration-200 cursor-pointer flex flex-col justify-center items-center gap-1 ${
                      selectedTimeline === opt.id
                        ? theme === 'light'
                          ? 'border-blue-500 bg-blue-50/50'
                          : 'border-[#7C3AED] bg-[#7C3AED]/8'
                        : theme === 'light'
                        ? 'border-slate-200 bg-white hover:border-slate-400'
                        : 'border-white/5 bg-[#111128]/40 hover:border-[#7C3AED]/20'
                    }`}
                  >
                    <div className={`font-bold text-sm flex items-center gap-1 ${theme === 'light' ? 'text-[#0F172A]' : 'text-white'}`}>
                      {opt.id === 'rush' && <Zap size={14} className="text-amber-500 fill-amber-500" />}
                      {opt.name}
                    </div>
                    <div className={`text-xs ${theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'}`}>
                      {opt.id === 'rush' ? '+25% Premium multiplier' : 'No express fees'}
                    </div>
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Right panel - Total Price Display Card Sticky */}
          <div className="lg:col-span-5 w-full sticky top-24">
            <div className={`rounded-2xl border p-8 shadow-2xl relative overflow-hidden text-center flex flex-col justify-between ${
              theme === 'light'
                ? 'bg-white border-slate-200 text-slate-800 shadow-slate-200/50'
                : 'bg-gradient-to-b from-[#111128] to-[#0A0A14] border-[#7C3AED]/20 text-white'
            }`}>
              
              {/* Decorative side badge */}
              <div className="absolute top-[16px] right-[16px] bg-gradient-to-r from-blue-600 to-indigo-500 text-white text-[10px] font-bold uppercase px-3 py-1 rounded-full flex items-center gap-1 shadow">
                <Sparkles size={11} /> 100% Guaranteed Estimate
              </div>

              <div>
                <Calculator className={`mx-auto mb-6 ${theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'}`} size={44} />
                <h3 className={`font-display text-xl font-bold mb-1 ${theme === 'light' ? 'text-[#0F172A]' : 'text-white'}`}>Your Curated Quote</h3>
                <p className={`text-xs mb-8 ${theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'}`}>
                  Based on custom selections fully matched to your local/global parameter requirements
                </p>

                {/* Main Estimated Cost Value display */}
                <div className="my-6">
                  <div className={`text-xs font-semibold uppercase tracking-widest ${theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'}`}>
                    Estimated Cost Range
                  </div>
                  <div className={`font-display text-4xl sm:text-5xl lg:text-[54px] font-extrabold tracking-tight mt-3 ${
                    theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'
                  }`}>
                    {formattedCost(finalCostPriceUSD * 0.95)} - {formattedCost(finalCostPriceUSD * 1.05)}
                  </div>
                  <div className={`text-xs mt-2 font-medium ${theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'}`}>
                    *Calculated beautifully in {currencyInfo.label}
                  </div>
                </div>

                <hr className={`my-8 border-dashed ${theme === 'light' ? 'border-slate-200' : 'border-white/10'}`} />

                {/* Selections breakdown */}
                <div className="flex flex-col gap-3 font-medium text-xs mb-8 text-left">
                  <div className="flex justify-between items-center">
                    <span className={theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'}>Design Stack Core:</span>
                    <span className={`font-semibold capitalize ${theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'}`}>{selectedService} Platform</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className={theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'}>Scope Setting:</span>
                    <span className={`font-semibold capitalize ${theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'}`}>{selectedScale.replace('-',' ')}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className={theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'}>Addons Checked:</span>
                    <span className={`font-semibold ${theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'}`}>{selectedAddons.length} Premium items</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className={theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'}>Delivery Speed:</span>
                    <span className={`font-semibold capitalize ${theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'}`}>{selectedTimeline} Sprint</span>
                  </div>
                </div>
              </div>

              {/* Direct CTA */}
              <div className="flex flex-col gap-3">
                <a
                  href="#calendar-booking"
                  className={`w-full py-4 rounded-xl text-center font-bold text-sm text-white shadow-xl hover:-translate-y-0.5 transition duration-200 flex items-center justify-center gap-2 cursor-pointer ${
                    theme === 'light'
                      ? 'bg-gradient-to-r from-blue-600 to-indigo-500 shadow-blue-500/25 hover:shadow-blue-500/40'
                      : 'bg-gradient-to-r from-[#7C3AED] to-[#A855F7] shadow-purple-500/25 hover:shadow-purple-500/40'
                  }`}
                >
                  Book Free Consultation <ArrowRight size={14} />
                </a>
                <p className={`text-[10px] ${theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'}`}>
                  Lock in this preliminary calculation & assign a project architect instantly
                </p>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
