/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { portfolioItems } from '../data';
import { useTheme } from './ThemeContext';

export default function Portfolio() {
  const [filter, setFilter] = useState('all');
  const { theme } = useTheme();

  const categories = [
    { value: 'all', label: 'All Work' },
    { value: 'web', label: 'Web Dev' },
    { value: 'brand', label: 'Branding' },
    { value: 'app', label: 'Mobile' },
    { value: 'seo', label: 'SEO' },
  ];

  const filteredItems = portfolioItems.filter(
    (item) => filter === 'all' || item.category === filter
  );

  return (
    <section className={`py-24 sm:py-32 transition-all duration-[400ms] ease-in-out ${
      theme === 'light' ? 'bg-[#FFFFFF] border-y border-slate-100' : 'bg-[#0F172A] border-y border-white/5'
    }`} id="work">
      <div className="max-w-[1200px] mx-auto px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-[680px] mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold tracking-wider uppercase text-[#A855F7] bg-[#7C3AED]/8 border border-[#7C3AED]/20 mb-5">
            Our Work
          </div>
          <h2 className={`font-display text-3xl sm:text-4xl lg:text-[48px] font-bold leading-[1.1] mb-5 transition-colors duration-[400ms] ${
            theme === 'light' ? 'text-[#0F172A]' : 'text-white'
          }`}>
            Projects that moved <span className="bg-gradient-to-r from-[#2563EB] via-[#7C3AED] to-[#06B6D4] bg-clip-text text-transparent">the needle</span>
          </h2>
          <p className={`text-base sm:text-lg leading-relaxed transition-colors duration-[400ms] ${
            theme === 'light' ? 'text-[#64748B]' : 'text-[#94A3B8]'
          }`}>
            Case studies showing real outcomes — not just pretty screens.
          </p>
        </div>

        {/* Categories filters */}
        <div className="flex gap-2 sm:gap-3 justify-center mb-12 sm:mb-16 flex-wrap">
          {categories.map((cat) => (
            <button
              key={cat.value}
              onClick={() => setFilter(cat.value)}
              className={`px-5 py-2 rounded-full text-xs sm:text-sm font-semibold transition cursor-pointer border ${
                filter === cat.value
                  ? theme === 'light'
                    ? 'bg-blue-50 border-blue-600 text-blue-600 shadow-md shadow-blue-500/5'
                    : 'bg-gradient-to-r from-[#2563EB]/15 to-[#06B6D4]/10 border-blue-500 text-white shadow-lg shadow-blue-500/5'
                  : theme === 'light'
                    ? 'border-slate-200 hover:border-slate-400 hover:text-slate-800 hover:bg-slate-50 text-[#64748B]'
                    : 'border-white/5 hover:border-blue-500/50 hover:text-white hover:bg-white/5 text-[#94A3B8]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredItems.map((item, idx) => {
            // First item spans 2 columns in standard views when length > 1
            const spanClass = filter === 'all' && idx === 0 && filteredItems.length > 1
              ? 'md:col-span-2'
              : 'col-span-1';

            return (
              <div
                key={item.id}
                className={`group relative flex flex-col rounded-2xl overflow-hidden hover:shadow-2xl transition-all duration-500 cursor-pointer border ${
                  theme === 'light'
                    ? 'bg-[#F8FAFC] border-slate-200/60 shadow-md shadow-slate-100 hover:border-blue-300'
                    : 'bg-[#111827]/40 border-white/5 hover:border-purple-500/20 hover:shadow-black/70'
                } ${spanClass}`}
                id={`portfolio-${item.id}`}
              >
                {/* Visual Thumbnail Frame */}
                <div className={`relative w-full aspect-[16/10] bg-gradient-to-br ${item.gradient} flex items-center justify-center text-7xl select-none overflow-hidden shrink-0`}>
                  {item.emoji}
                  
                  {/* Glass Card Shadow Overlay */}
                  <div className="absolute inset-0 bg-black/40 xl:bg-gradient-to-t xl:from-black/70 xl:to-transparent opacity-80" />
                  
                  {/* Hover visual details overlay - revealed smoothly on desktop */}
                  <div className={`absolute inset-0 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6 select-text overflow-y-auto ${
                    theme === 'light'
                      ? 'bg-white/95 xl:bg-gradient-to-t xl:from-white xl:via-white/98 xl:to-slate-50'
                      : 'bg-[#0F172A]/95 xl:bg-gradient-to-t xl:from-[#0F172A] xl:via-[#0F172A]/98 xl:to-[#0a0a1e]/85'
                  }`}>
                    <div className="text-[10px] sm:text-xs font-bold leading-none tracking-widest text-[#2563EB] uppercase mb-1.5">
                      {item.categoryLabel}
                    </div>
                    <div className={`font-display text-lg sm:text-xl font-bold mb-2 leading-tight ${
                      theme === 'light' ? 'text-[#0F172A]' : 'text-white'
                    }`}>
                      {item.title}
                    </div>
                    <div className={`text-xs sm:text-sm leading-relaxed mb-5 font-normal ${
                      theme === 'light' ? 'text-[#64748B]' : 'text-[#94A3B8]'
                    }`}>
                      {item.description}
                    </div>

                    {/* Metrics row */}
                    <div className={`flex gap-6 border-t pt-4 ${
                      theme === 'light' ? 'border-slate-200' : 'border-white/5'
                    }`}>
                      {item.metrics.map((m, mIdx) => (
                        <div key={mIdx} className="flex-1 min-w-0">
                          <div className="font-display text-sm sm:text-base font-extrabold text-[#2563EB] truncate">
                            {m.value}
                          </div>
                          <div className={`text-[10px] mt-0.5 leading-tight uppercase tracking-wider font-semibold truncate ${
                            theme === 'light' ? 'text-[#64748B]' : 'text-[#6B6590]'
                          }`}>
                            {m.label}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Meta details always visible below thumbnail (vital for non-hover / mobile displays!) */}
                <div className="p-5 flex flex-col justify-between grow">
                  <div>
                    <h3 className={`font-display text-base font-bold transition-colors leading-tight ${
                      theme === 'light' ? 'text-[#0F172A] group-hover:text-[#2563EB]' : 'text-white group-hover:text-[#A855F7]'
                    }`}>
                      {item.title}
                    </h3>
                    <div className="text-xs text-[#6B6590] mt-1.5 font-medium flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#2563EB]/80" />
                      {item.categoryLabel}
                    </div>
                  </div>
                  
                  {/* Mobile Metrics block (fully transparent and accessible at mobile views) */}
                  <div className={`mt-4 pt-3.5 border-t grid grid-cols-2 gap-3 md:hidden ${
                    theme === 'light' ? 'border-slate-200' : 'border-white/5'
                  }`}>
                    {item.metrics.map((m, mIdx) => (
                      <div key={mIdx}>
                        <div className="font-display text-base font-extrabold text-[#2563EB]">{m.value}</div>
                        <div className="text-[10px] font-semibold text-[#6B6590] uppercase tracking-wider">{m.label}</div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
