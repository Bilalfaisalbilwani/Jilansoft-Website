/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Calendar, Clock, CheckCircle2, ChevronLeft, ChevronRight, User, Mail, Globe, Sparkles } from 'lucide-react';
import { useTheme } from './ThemeContext';

interface BookingDetails {
  dateString: string;
  timeSlot: string;
  timezone: string;
  name: string;
  email: string;
  websiteUrl?: string;
  projectGoal: string;
}

const TIMEZONES = [
  { value: 'America/New_York', label: 'Eastern Time (UTC-4) - Intl' },
  { value: 'America/Los_Angeles', label: 'Pacific Time (UTC-7) - Intl' },
  { value: 'Europe/London', label: 'London Time (UTC+1) - Intl' },
  { value: 'Asia/Kolkata', label: 'Indian Standard Time (UTC+5:30) - Local' },
  { value: 'Asia/Dubai', label: 'Gulf Standard Time (UTC+4) - Local' },
];

const TIME_SLOTS = [
  '09:00 AM',
  '10:30 AM',
  '01:00 PM',
  '02:30 PM',
  '04:00 PM',
  '05:30 PM',
];

export default function CalendarBooking() {
  const { theme } = useTheme();

  // Switch to show/hide full calendar details on deliberate click
  const [showCalendarForm, setShowCalendarForm] = useState(false);

  // Current calendar navigation view
  const [currentYear, setCurrentYear] = useState(2026);
  const [currentMonth, setCurrentMonth] = useState(5); // June is 5 (0-indexed)

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Selected parameters
  const [selectedDay, setSelectedDay] = useState<number | null>(24); // default select June 24th
  const [selectedSlot, setSelectedSlot] = useState<string>('10:30 AM');
  const [selectedTimezone, setSelectedTimezone] = useState<string>('America/New_York');

  // Lead fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [projectGoal, setProjectGoal] = useState('Explore Software Development Sprints');

  // Booking states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [savedBookings, setSavedBookings] = useState<BookingDetails[]>([]);

  // Calculate day counts
  const totalDaysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfMonthIndex = new Date(currentYear, currentMonth, 1).getDay();

  // Handle month navigation
  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
    setSelectedDay(null);
  };

  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonth((m) => m - 1);
    }
    setSelectedDay(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDay || !selectedSlot || !name || !email) return;

    setIsSubmitting(true);
    const dateString = `${monthNames[currentMonth]} ${selectedDay}, ${currentYear}`;
    
    const newBooking: BookingDetails = {
      dateString,
      timeSlot: selectedSlot,
      timezone: selectedTimezone,
      name,
      email,
      websiteUrl,
      projectGoal,
    };

    // Save locally
    setTimeout(() => {
      setSavedBookings((prev) => [newBooking, ...prev]);
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 1500);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setName('');
    setEmail('');
    setWebsiteUrl('');
    setSelectedDay(24);
    setSelectedSlot('10:30 AM');
  };

  // Generate blank placeholder cells and day buttons
  const calendarDays = [];
  for (let i = 0; i < firstDayOfMonthIndex; i++) {
    calendarDays.push(<div key={`blank-${i}`} className="w-[36px] h-[36px] sm:w-[44px] sm:h-[44px]" />);
  }

  for (let day = 1; day <= totalDaysInMonth; day++) {
    const isSelected = selectedDay === day;
    // Check if weekend to style differently
    const dayOfWeek = new Date(currentYear, currentMonth, day).getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

    calendarDays.push(
      <button
        key={`day-${day}`}
        type="button"
        onClick={() => setSelectedDay(day)}
        className={`w-9 h-9 sm:w-11 sm:h-11 rounded-full text-xs sm:text-sm font-semibold flex items-center justify-center transition cursor-pointer ${
          isSelected
            ? theme === 'light'
              ? 'bg-gradient-to-r from-blue-600 to-indigo-500 text-white shadow-lg shadow-blue-500/20'
              : 'bg-gradient-to-r from-[#7C3AED] to-[#A855F7] text-white shadow-lg shadow-purple-500/20'
            : isWeekend
            ? 'text-[#6B6590]/50 hover:bg-purple-500/5'
            : theme === 'light'
            ? 'text-slate-800 hover:bg-slate-200/60'
            : 'text-[#F0EDFF] hover:bg-white/5'
        }`}
      >
        {day}
      </button>
    );
  }

  return (
    <section 
      className={`py-24 sm:py-32 border-y transition-all duration-[400ms] ease-in-out ${
        theme === 'light' 
          ? 'bg-[#FFFFFF] border-slate-100 text-slate-800' 
          : 'bg-[#020617] border-white/5 text-[#F0EDFF]'
      }`} 
      id="calendar-booking"
    >
      <div className="max-w-[1200px] mx-auto px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-[720px] mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold tracking-wider uppercase text-[#A855F7] bg-[#7C3AED]/8 border border-[#7C3AED]/20 mb-5">
            1-on-1 Consultation
          </div>
          <h2 className={`font-display text-3xl sm:text-4xl lg:text-[48px] font-bold leading-[1.1] mb-5 transition-colors duration-[400ms] ${
            theme === 'light' ? 'text-[#0F172A]' : 'text-white'
          }`}>
            Book a Free <span className="bg-gradient-to-r from-[#2563EB] via-[#7C3AED] to-[#06B6D4] bg-clip-text text-transparent">Live Consultation</span>
          </h2>
          <p className={`text-base sm:text-lg leading-relaxed transition-colors duration-[400ms] ${theme === 'light' ? 'text-[#64748B]' : 'text-[#A09BB8]'}`}>
            Select a live date and session parameters below to block 30 minutes on an agency architect's schedule. Fully responsive, local and global timezones.
          </p>
        </div>

        {/* Conditional booking interactive elements */}
        {!showCalendarForm ? (
          <div className="max-w-2xl mx-auto">
            <div className={`p-8 sm:p-12 rounded-3xl border text-center relative overflow-hidden transition-all duration-[400ms] shadow-2xl ${
              theme === 'light'
                ? 'bg-[#F8FAFC] border-slate-200 shadow-slate-200/50'
                : 'bg-gradient-to-b from-[#111128] to-[#0A0A14] border-white/5'
            }`}>
              {/* Modern ambient visual glow */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-purple-500/10 blur-[90px] rounded-full pointer-events-none" />
              
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold text-[#2563EB] bg-blue-500/10 mb-6 font-semibold uppercase dark:text-[#A855F7] dark:bg-[#7C3AED]/10">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Live Consulting Slots Open Today
              </div>
              
              <h3 className={`font-display text-2xl sm:text-3xl font-extrabold mb-4 tracking-tight transition-colors duration-[400ms] ${
                theme === 'light' ? 'text-[#0F172A]' : 'text-white'
              }`}>
                Get Your Live Strategy Consultation
              </h3>
              
              <p className={`text-sm sm:text-base leading-relaxed mb-8 max-w-lg mx-auto transition-colors duration-[400ms] ${
                theme === 'light' ? 'text-[#64748B]' : 'text-[#A09BB8]'
              }`}>
                Schedule a 1-on-1 strategy call with a Jilansoft lead engineer. We'll analyze your requirements, design technical roadmap parameters, and establish key layouts absolutely free.
              </p>
              
              <button
                type="button"
                onClick={() => setShowCalendarForm(true)}
                className={`inline-flex items-center gap-2.5 px-8 py-4 rounded-xl font-bold text-sm text-white shadow-xl hover:scale-[1.02] active:scale-95 transition-all duration-200 cursor-pointer ${
                  theme === 'light'
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-500 shadow-blue-500/25 hover:shadow-blue-500/35'
                    : 'bg-gradient-to-r from-[#7C3AED] to-[#A855F7] shadow-purple-500/20 hover:shadow-purple-500/35'
                }`}
              >
                <Calendar size={18} />
                Open Interactive Booking Calendar
              </button>
              
              <div className="flex gap-6 justify-center items-center mt-8 text-xs text-[#6B6590]">
                <span>⏱️ 30-Min Live Call</span>
                <span>•</span>
                <span>💬 Meet / Zoom</span>
                <span>•</span>
                <span>⚡ Zero Commitments</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            <div className="flex justify-start">
              <button
                type="button"
                onClick={() => setShowCalendarForm(false)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  theme === 'light' 
                    ? 'bg-slate-200 hover:bg-slate-300 text-slate-800' 
                    : 'bg-white/5 hover:bg-white/10 text-[#F0EDFF]'
                }`}
              >
                <ChevronLeft size={14} /> Minimize Scheduler
              </button>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Left panel - Calendar Grid & Time Slots */}
              <div className={`lg:col-span-7 rounded-2xl border p-6 sm:p-8 text-left ${
                theme === 'light' ? 'bg-[#F8FAFC] border-slate-200' : 'bg-[#111128]/50 border-white/5'
              }`}>
                
                {/* Year / Month navigation Bar */}
                <div className="flex items-center justify-between mb-8">
                  <span className={`font-display font-extrabold text-base sm:text-lg flex items-center gap-2 ${
                    theme === 'light' ? 'text-[#0F172A]' : 'text-white'
                  }`}>
                    <Calendar className={theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'} size={20} />
                    {monthNames[currentMonth]} {currentYear}
                  </span>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={prevMonth}
                      className={`w-9 h-9 rounded-full border flex items-center justify-center transition cursor-pointer ${
                        theme === 'light' ? 'border-slate-300 hover:bg-slate-200 text-slate-800' : 'border-white/5 hover:bg-white/5 text-white'
                      }`}
                    >
                      <ChevronLeft size={16} />
                    </button>
                    <button
                      type="button"
                      onClick={nextMonth}
                      className={`w-9 h-9 rounded-full border flex items-center justify-center transition cursor-pointer ${
                        theme === 'light' ? 'border-slate-300 hover:bg-slate-200 text-slate-800' : 'border-white/5 hover:bg-white/5 text-white'
                      }`}
                    >
                      <ChevronRight size={16} />
                    </button>
                  </div>
                </div>

                {/* Weekday headers */}
                <div className={`grid grid-cols-7 gap-1 text-center text-xs font-bold uppercase tracking-wider mb-3 ${
                  theme === 'light' ? 'text-slate-400' : 'text-[#6B6590]'
                }`}>
                  <div>Sun</div>
                  <div>Mon</div>
                  <div>Tue</div>
                  <div>Wed</div>
                  <div>Thu</div>
                  <div>Fri</div>
                  <div>Sat</div>
                </div>

                {/* Day nodes wrapper */}
                <div className="grid grid-cols-7 gap-1 justify-items-center mb-8">
                  {calendarDays}
                </div>

                <hr className={`my-8 ${theme === 'light' ? 'border-slate-200' : 'border-white/5'}`} />

                {/* Timezone configuration Selector */}
                <div className="mb-6 flex flex-col items-start font-sans">
                  <label className={`text-xs font-bold uppercase tracking-wide mb-3 ${
                    theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'
                  }`}>
                    Your Preferred Timezone:
                  </label>
                  <select
                    value={selectedTimezone}
                    onChange={(e) => setSelectedTimezone(e.target.value)}
                    className={`w-full max-w-md rounded-lg px-4 py-3 text-sm font-medium cursor-pointer outline-none border ${
                      theme === 'light'
                        ? 'bg-white border-slate-300 text-slate-800 focus:border-blue-500'
                        : 'bg-[#0A0A14] border-white/10 text-white focus:border-purple-500'
                    }`}
                  >
                    {TIMEZONES.map((tz) => (
                      <option key={tz.value} value={tz.value}>
                        {tz.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Dynamic visual slot selector */}
                <div className="flex flex-col items-start font-sans">
                  <span className={`text-xs font-bold uppercase tracking-wide mb-3 flex items-center gap-1.5 ${
                    theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'
                  }`}>
                    <Clock size={14} /> Available Slots for {selectedDay ? `${monthNames[currentMonth]} ${selectedDay}` : 'Selected Date'}:
                  </span>
                  
                  {selectedDay ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 w-full">
                      {TIME_SLOTS.map((slot) => {
                        const isPicked = selectedSlot === slot;
                        return (
                          <button
                            key={slot}
                            type="button"
                            onClick={() => setSelectedSlot(slot)}
                            className={`py-3 rounded-xl border text-center text-xs font-semibold uppercase tracking-wider transition duration-200 cursor-pointer ${
                              isPicked
                                ? theme === 'light'
                                  ? 'bg-blue-50 border-blue-600 text-blue-600 shadow-sm'
                                  : 'bg-[#7C3AED]/10 text-[#A855F7] border-[#7C3AED] shadow-sm'
                                : theme === 'light'
                                ? 'border-slate-200 bg-white text-slate-700 hover:border-slate-400'
                                : 'border-white/5 bg-[#0a0a14]/65 text-[#F0EDFF] hover:border-purple-500/20'
                            }`}
                          >
                            {slot}
                          </button>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="py-6 px-4 border border-dashed rounded-xl w-full text-center text-[#6B6590] text-sm">
                      Please tap a calendar date to view operational slots
                    </div>
                  )}
                </div>

              </div>

              {/* Right panel - Interactive Intake Form / Details Success */}
              <div className="lg:col-span-5 w-full font-sans">
                <div className={`rounded-2xl border p-6 sm:p-8 shadow-2xl relative overflow-hidden ${
                  theme === 'light'
                    ? 'bg-[#F8FAFC] border-slate-200 text-slate-800'
                    : 'bg-gradient-to-b from-[#111128] to-[#0A0A14] border-white/5 text-white'
                }`}>
                  
                  {isSubmitted ? (
                    /* Animated success message */
                    <div className="flex flex-col items-center justify-center text-center py-10 gap-5 animate-scale-in">
                      <div className="w-16 h-16 rounded-full bg-green-500/15 border border-green-500/30 flex items-center justify-center text-green-500 mb-2">
                        <CheckCircle2 size={36} />
                      </div>
                      <h3 className={`font-display text-2xl font-bold ${theme === 'light' ? 'text-[#0F172A]' : 'text-white'}`}>Consultation Booked!</h3>
                      <p className={`text-sm leading-relaxed max-w-sm ${theme === 'light' ? 'text-slate-500' : 'text-[#A09BB8]'}`}>
                        Success! {name}, We booked your 30-min strategy review session on:
                      </p>
                      
                      {/* Summary ticket */}
                      <div className={`w-full border rounded-xl p-4 text-left flex flex-col gap-2 mt-2 ${
                        theme === 'light' ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#0A0A14] border-white/5'
                      }`}>
                        <div className="text-xs font-bold text-[#6B6590] uppercase tracking-wider">Appointment parameters</div>
                        <div className={`text-sm font-bold flex items-center gap-2 ${theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'}`}>
                          📅 {monthNames[currentMonth]} {selectedDay}, {currentYear}
                        </div>
                        <div className={`text-sm font-semibold flex items-center gap-2 ${theme === 'light' ? 'text-slate-800' : 'text-white'}`}>
                          🕒 {selectedSlot} ({selectedTimezone.split('/')[1]?.replace('_', ' ')})
                        </div>
                        <div className={`text-xs border-t pt-2 mt-1 ${theme === 'light' ? 'border-slate-100 text-slate-400' : 'border-white/5 text-[#6B6590]'}`}>
                          An calendar invite alongside a custom Google Meet video bridge has been emailed to {email}.
                        </div>
                      </div>

                      <button
                        onClick={handleReset}
                        className="mt-6 px-6 py-2.5 rounded-lg text-sm font-semibold text-white bg-gradient-to-r from-green-600 to-emerald-500 hover:opacity-90 shadow-md cursor-pointer"
                      >
                        Schedule Another Session
                      </button>
                    </div>
                  ) : (
                    /* Real intake form */
                    <form onSubmit={handleSubmit} className="flex flex-col gap-4 text-left">
                      <div className="inline-flex items-center gap-1 pb-2">
                        <Sparkles size={16} className={`animate-pulse ${theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'}`} />
                        <h3 className={`font-display font-extrabold text-lg ${theme === 'light' ? 'text-[#0F172A]' : 'text-white'}`}>Intake Parameters</h3>
                      </div>

                      <div className="flex flex-col items-start">
                        <label className="text-[10px] font-extrabold uppercase tracking-widest text-[#6B6590] mb-2 flex items-center gap-1.5">
                          <User size={12} /> Contact Name
                        </label>
                        <input
                          required
                          type="text"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Devin Smith"
                          className={`w-full rounded-lg px-4 py-3 text-sm outline-none border ${
                            theme === 'light'
                              ? 'bg-white border-slate-300 text-slate-800 placeholder-slate-400 focus:border-blue-500'
                              : 'bg-white/4 border-white/10 text-white placeholder-[#6B6590] focus:border-purple-500'
                          }`}
                        />
                      </div>

                      <div className="flex flex-col items-start">
                        <label className="text-[10px] font-extrabold uppercase tracking-widest text-[#6B6590] mb-2 flex items-center gap-1.5">
                          <Mail size={12} /> Email Address
                        </label>
                        <input
                          required
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="devin@company.com"
                          className={`w-full rounded-lg px-4 py-3 text-sm outline-none border ${
                            theme === 'light'
                              ? 'bg-white border-slate-300 text-slate-800 placeholder-slate-400 focus:border-blue-500'
                              : 'bg-white/4 border-white/10 text-white placeholder-[#6B6590] focus:border-purple-500'
                          }`}
                        />
                      </div>

                      <div className="flex flex-col items-start">
                        <label className="text-[10px] font-extrabold uppercase tracking-widest text-[#6B6590] mb-2 flex items-center gap-1.5">
                          <Globe size={12} /> Current Website (Optional)
                        </label>
                        <input
                          type="url"
                          value={websiteUrl}
                          onChange={(e) => setWebsiteUrl(e.target.value)}
                          placeholder="https://company.com"
                          className={`w-full rounded-lg px-4 py-3 text-sm outline-none border ${
                            theme === 'light'
                              ? 'bg-white border-slate-300 text-slate-800 placeholder-slate-400 focus:border-blue-500'
                              : 'bg-white/4 border-white/10 text-white placeholder-[#6B6590] focus:border-purple-500'
                          }`}
                        />
                      </div>

                      <div className="flex flex-col items-start">
                        <label className="text-[10px] font-extrabold uppercase tracking-widest text-[#6B6590] mb-2">
                          Primary Project Objective
                        </label>
                        <select
                          value={projectGoal}
                          onChange={(e) => setProjectGoal(e.target.value)}
                          className={`w-full rounded-lg px-4 py-3 text-sm cursor-pointer outline-none border appearance-none ${
                            theme === 'light'
                              ? 'bg-white border-slate-300 text-slate-800 focus:border-blue-500'
                              : 'bg-[#111128] border-white/10 text-white focus:border-purple-500'
                          }`}
                        >
                          <option value="Explore Software Development Sprints">Web Development Project</option>
                          <option value="Custom CRM & SaaS Analytics Architecture">Custom SaaS Platform</option>
                          <option value="Mobile iOS / Android scale strategy">Mobile Software Development</option>
                          <option value="Design Sprints & SEO optimization parameters">Growth & Conversion Auditing</option>
                        </select>
                      </div>

                      <button
                        type="submit"
                        disabled={isSubmitting || !selectedDay}
                        className={`w-full mt-4 py-4 rounded-xl text-center font-bold text-sm text-white shadow-xl hover:scale-[1.01] transition-transform cursor-pointer disabled:opacity-50 disabled:pointer-events-none ${
                          theme === 'light'
                            ? 'bg-gradient-to-r from-blue-600 to-indigo-500 shadow-blue-500/25 hover:shadow-blue-500/40'
                            : 'bg-gradient-to-r from-[#7C3AED] to-[#A855F7] shadow-purple-500/25 hover:shadow-purple-500/40'
                        }`}
                      >
                        {isSubmitting ? 'Securing your slot...' : 'Confirm consultation booking'}
                      </button>
                    </form>
                  )}

                  {/* Show locally booked list beautifully */}
                  {savedBookings.length > 0 && (
                    <div className={`mt-8 pt-6 text-left border-t ${theme === 'light' ? 'border-slate-200' : 'border-white/5'}`}>
                      <div className={`text-[10px] font-extrabold uppercase tracking-wider mb-3 ${theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'}`}>
                        Your Scheduled Consultations ({savedBookings.length})
                      </div>
                      <div className="flex flex-col gap-2">
                        {savedBookings.map((b, bIdx) => (
                          <div key={bIdx} className={`text-xs p-2.5 rounded-lg border flex justify-between items-center ${
                            theme === 'light' ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#0A0A14] border-white/5'
                          }`}>
                            <div>
                              <span className="font-bold">{b.name}</span> · {b.dateString}
                            </div>
                            <span className={`font-semibold ${theme === 'light' ? 'text-blue-600' : 'text-[#A855F7]'}`}>{b.timeSlot}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                </div>
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
}
